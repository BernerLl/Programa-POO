package ec.edu.espoch;

import ec.edu.espoch.interfaz.DerivacionImplicita;


public class ProyectoDerivacion {

    public static void main(String[] args) {
        DerivacionImplicita objInterfaz = new DerivacionImplicita();
        objInterfaz.setVisible(true);
    }
    
}
